#include <stdio.h>

void main() {
    int a = 7;
    int b = 9;
    int ndungutse;
    ndungutse = (a<b)? a:b;
    printf("%d", ndungutse);
}